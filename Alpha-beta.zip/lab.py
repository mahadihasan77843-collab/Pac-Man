# multiAgents.py
from util import manhattanDistance
from game import Directions
import random, util
from game import Agent

class ReflexAgent(Agent):
    """A reflex agent chooses an action at each choice point using a state evaluation function."""

    def getAction(self, gameState):
        legalMoves = gameState.getLegalActions()
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [i for i in range(len(scores)) if scores[i] == bestScore]
        chosenIndex = random.choice(bestIndices)
        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        return successorGameState.getScore()

def scoreEvaluationFunction(currentGameState):
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """Base class for minimax, alpha-beta, and expectimax agents."""

    def __init__(self, evalFn='scoreEvaluationFunction', depth='2'):
        self.index = 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """Minimax agent."""

    def getAction(self, gameState):
        action, _ = self.minimax(0, 0, gameState)
        return action

    def minimax(self, depth, agentIndex, gameState):
        if agentIndex >= gameState.getNumAgents():
            agentIndex = 0
            depth += 1
        if depth == self.depth or not gameState.getLegalActions(agentIndex):
            return None, self.evaluationFunction(gameState)

        if agentIndex == 0:  # Max (Pacman)
            best_score = float('-inf')
            best_action = None
            for action in gameState.getLegalActions(agentIndex):
                _, score = self.minimax(depth, agentIndex + 1, gameState.generateSuccessor(agentIndex, action))
                if score > best_score:
                    best_score = score
                    best_action = action
            return best_action, best_score
        else:  # Min (Ghosts)
            best_score = float('inf')
            best_action = None
            for action in gameState.getLegalActions(agentIndex):
                _, score = self.minimax(depth, agentIndex + 1, gameState.generateSuccessor(agentIndex, action))
                if score < best_score:
                    best_score = score
                    best_action = action
            return best_action, best_score

class AlphaBetaAgent(MultiAgentSearchAgent):
    """Minimax agent with alpha-beta pruning."""

    def getAction(self, gameState):
        action, _ = self.alphabeta(0, 0, gameState, float('-inf'), float('inf'))
        return action

    def alphabeta(self, depth, agentIndex, gameState, alpha, beta):
        if agentIndex >= gameState.getNumAgents():
            agentIndex = 0
            depth += 1
        if depth == self.depth or not gameState.getLegalActions(agentIndex):
            return None, self.evaluationFunction(gameState)

        if agentIndex == 0:  # Max (Pacman)
            best_score = float('-inf')
            best_action = None
            for action in gameState.getLegalActions(agentIndex):
                _, score = self.alphabeta(depth, agentIndex + 1, gameState.generateSuccessor(agentIndex, action), alpha, beta)
                if score > best_score:
                    best_score = score
                    best_action = action
                if best_score > beta:
                    return best_action, best_score
                alpha = max(alpha, best_score)
            return best_action, best_score
        else:  # Min (Ghosts)
            best_score = float('inf')
            best_action = None
            for action in gameState.getLegalActions(agentIndex):
                _, score = self.alphabeta(depth, agentIndex + 1, gameState.generateSuccessor(agentIndex, action), alpha, beta)
                if score < best_score:
                    best_score = score
                    best_action = action
                if best_score < alpha:
                    return best_action, best_score
                beta = min(beta, best_score)
            return best_action, best_score

class ExpectimaxAgent(MultiAgentSearchAgent):
    """Expectimax agent (not implemented fully)."""
    def getAction(self, gameState):
        return random.choice(gameState.getLegalActions(0))  # placeholder

def betterEvaluationFunction(currentGameState):
    """Better evaluation function (placeholder)."""
    return currentGameState.getScore()

better = betterEvaluationFunction
